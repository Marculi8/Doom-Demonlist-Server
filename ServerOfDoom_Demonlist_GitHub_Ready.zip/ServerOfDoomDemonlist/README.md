# Server of Doom Demonlist

Custom Geometry Dash demonlist based on the Shitty List / GDListTemplate.

## How to use this

1. Go to https://github.com/TheShittyList/GDListTemplate
2. Click **Use this template** → create a new repository under **your** GitHub account
3. Download this folder (or the zip)
4. Replace the entire `data` folder in your new repo with the `data` folder from this package
5. (Optional) Edit `index.html` and other files to change the name from "Shitty List" to "Server of Doom Demonlist"
6. Enable **GitHub Pages** on your repository (Settings → Pages → Deploy from main branch)
7. Your list will be live at `https://YOURUSERNAME.github.io/YOUR-REPO-NAME`

## Editing the list later

- To change the order of levels → edit `data/_list.json`
- To add a new level → create a new `.json` file in `data/` and add its filename (without .json) to `_list.json`
- To add records → open the level's `.json` and add objects to the `"records"` array
- To change editors → edit `data/_editors.json`

## Current List (26 levels)

1. Sonic Wave
2. Bloodbath
3. The Flawless
4. Acu
5. Cataclysm
6. Rauchkammer
7. Ice Carbon Diablo X
8. BuTiTi II
9. Future Funk II
10. Acropolis
11. 8o
12. Rupture
13. Backrooms
14. Death Note
15. Poltergeist
16. Windy Landscape
17. Magma Bound
18. CraZy II
19. Lit Fuse
20. The Furious
21. Shitty Sonic Wave (Marculi8 Version)
22. Forest Temple
23. Fairydust
24. Future Funk
25. Fnafbass
26. Thermodynamix

Made for you by Mommy ❤️
